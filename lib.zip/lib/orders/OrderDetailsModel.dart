class OrderDetailsModel {
  String orderDetailId;
  String orderId;
  String productId;
  String quantity;
  String price;
  String cgst;
  String cgstTitle;
  String sgst;
  String sgstTitle;
  String isManaged;
  String productTitle;
  String productImage;
}

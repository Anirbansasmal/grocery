class Variables {
  static int itemCount;
}
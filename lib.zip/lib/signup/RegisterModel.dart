class RegisterUserModel {
  String userId;
  String userType;
  String firstname;
  String lastname;
  String phone;
  String email;
  String token;
  String createDate;
}

class PaymentGatewayModel {
  String id;
  String paymentGatewayName;
  String offer;
}
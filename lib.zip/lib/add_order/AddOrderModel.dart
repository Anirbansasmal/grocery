class AddOrderModel {
  String status;
  String message;
  int orderId;
  String userId;
  String orderUniqueId;
  double orderTotalValue;
  int userDiscount;
  int couponDiscount;
  String orderDate;
  String billingName;
  String billingEmail;
  String billingPhone;
  String billingFlatHouseFloorBuilding;
  String billingLocality;
  String billingLandmark;
  String billingCity;
  String billingState;
  String billingPincode;
  String billingAddressId;
  String paymentStatus;
  String paymentMethod;
  int orderStatus;
}

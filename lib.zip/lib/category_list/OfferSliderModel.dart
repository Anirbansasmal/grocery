class OfferSliderModel {
  String name;
  String id;
  String categoryId;
  String offerText;
  String offerDiscount;
  String sliderImage;
  String status;
}
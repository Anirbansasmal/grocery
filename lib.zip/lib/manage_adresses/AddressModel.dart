class AddressModel{
  String id;
  String userId;
  String defaultBilling;
  String name;
  String phone;
  String pincode;
  String flatHouseFloorBuilding;
  String locality;
  String landmark;
  String city;
  String state;
  String country;
  String email;
  String addressType;
  String createDt;
}
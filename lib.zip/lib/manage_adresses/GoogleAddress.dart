import 'package:flutter/material.dart';

class GoogleAddress extends StatefulWidget {
  const GoogleAddress({Key key}) : super(key: key);

  @override
  _GoogleAddressState createState() => _GoogleAddressState();
}

class _GoogleAddressState extends State<GoogleAddress> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

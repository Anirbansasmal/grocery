class ReviewsModel {
  String reviewId;
  String productId;
  String userId;
  String name;
  String emailId;
  String message;
  String dateAdded;
  String productTitle;
  String firstname;
  String lastname;
  String reviewDateStr;
}
class ShoppingCartModel{
  // String status;
  String row_id;
  String user_id;
  String product_id;
  String name;
  String price;
  String qty;
  String regularPrice;
  String product_image;
}